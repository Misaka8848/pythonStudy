from distutils.core import setup

setup(
    name='AthleteList',
    version='1.0.0',
    packages=[''],
    url='',
    license='',
    author='han',
    author_email='',
    description=''
)
