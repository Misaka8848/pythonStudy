from distutils.core import setup

setup(
    name='neastet',
    version='1.0.0',
    packages=[''],
    url='',
    license='',
    author='han',
    author_email='',
    description=''
)
